package com.rays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.rays.model.ConnectionFactory;
import com.rays.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	Connection con=null;
	public EmployeeDAOImpl() {
		con=ConnectionFactory.openConn();
	}
	@Override
	public int saveEmployee(Employee emp) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("insert into employee values(?,?,?,?)");
			ps.setInt(1, emp.getEmpid());
			ps.setString(2, emp.getEmpname());
			ps.setInt(3, emp.getEmpage());
			ps.setDouble(4, emp.getEmpsalary());
			status=ps.executeUpdate();
		}catch (Exception e) {
			System.out.println("Error in Insert Employee "+e);
		}
		return status;
	}

	@Override
	public int updateEmployee(Employee emp) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("update employee set empname=?,empage=?,empsalary=? where empid=?");
			ps.setInt(4, emp.getEmpid());
			ps.setString(1, emp.getEmpname());
			ps.setInt(2, emp.getEmpage());
			ps.setDouble(3, emp.getEmpsalary());
			status=ps.executeUpdate();
		}catch (Exception e) {
			System.out.println("Error in Update Employee "+e);
		}
		return status;
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> listEmp=new ArrayList<Employee>();
		try {			
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from employee");
			while(rs.next())
			{
				Employee emp=new Employee();
				emp.setEmpid(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setEmpage(rs.getInt(3));
				emp.setEmpsalary(rs.getDouble(4));
				listEmp.add(emp);
			}
		} catch (Exception e) {
			System.out.println("Error in getAll Employee "+e);
		}
		return listEmp;
	}

	@Override
	public int deleteEmployee(int empid) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("delete from employee where empid=?");
			ps.setInt(1, empid);
			status=ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error in delete Employee :"+e);
		}
		return status;
	}
	@Override
	public Employee getByEmployeeId(int empid) {
		Employee emp=null;
		try {			
			PreparedStatement ps=con.prepareStatement("select * from employee where empid=?");
			ps.setInt(1, empid);
			ResultSet rs=ps.executeQuery();			
			if(rs.next())
			{
				emp=new Employee();
				emp.setEmpid(rs.getInt(1));
				emp.setEmpname(rs.getString(2));
				emp.setEmpage(rs.getInt(3));
				emp.setEmpsalary(rs.getDouble(4));				
			}
		} catch (Exception e) {
			System.out.println("Error in getByID "+e);
		}
		return emp;
	}

}

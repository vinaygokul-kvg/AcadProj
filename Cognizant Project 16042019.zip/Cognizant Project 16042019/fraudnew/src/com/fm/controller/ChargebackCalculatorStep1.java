package com.fm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fm.model.inter.CustomerTransactionsDAO;
import com.fm.model.inter.CustomerTransactionsDAOimpl;
import com.fm.model.inter.FormDAO;
import com.fm.model.inter.FormDAOImpl;
import com.fm.model.pojo.CustomerDetails;
import com.fm.model.pojo.CustomerTransactions;
import com.fm.model.pojo.Form;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;  

/**
 * Servlet implementation class SubmitForm
 */
@WebServlet("/ChargebackCalculatorStep1.do")
public class ChargebackCalculatorStep1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChargebackCalculatorStep1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		
		int accountnumber=Integer.parseInt(request.getParameter("accountnumber"));
		/*CustomerTransactions ct=new CustomerTransactions();
		ct.setAccountnumber(accountnumber);
		request.setAttribute("accno", ct);*/
		
		CustomerTransactionsDAO ctdao=new CustomerTransactionsDAOimpl();
		List<CustomerTransactions> datePaymentlist= ctdao.checkBillTransaction(accountnumber);
		
		String transactiondate="";
		String paymentdetails="";
		for(CustomerTransactions ctl:datePaymentlist)
		{
			
			transactiondate=ctl.getDate();
			paymentdetails=ctl.getPaymentdetails();
		}
		
		
		
		
		   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		   LocalDateTime now = LocalDateTime.now();
		   String currentdate=dtf.format(now);
		   
		   
		   if (currentdate.compareTo(transactiondate) > 0) { 
			   
	            //  No fine
	            
	        } 
	  
	        else if (currentdate.compareTo(transactiondate) < 0) { 
	  
	            // Fine
	            
	        } 
		
		/*
		
		SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
		

		try {
		    Date date1 = myFormat.parse(transactiondate);
		    Date date2 = myFormat.parse(currentdate);
		    long diff = date2.getTime() - date1.getTime();
		    long daysdifference= TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		*/
		
		
		
		RequestDispatcher rd=request.getRequestDispatcher("ChargebackCalcuFormStep2.jsp");
		
		/*Form fm=new Form(firstname, lastname, age, gender, contactnumber, city, state, userid, password);
		FormDAO fmdao=new FormDAOImpl();
		int status=fmdao.saveForm(fm);
		RequestDispatcher rd=request.getRequestDispatcher("index.html");
		if(status==1)
		{
			pw.println("<span style=color:green;font-size:20px;>New user created Successfully</span>");
			rd.include(request, response);
		}
		else
		{
			pw.println("<span style=color:red;size:20px>Failed Adding Customer</span>");
			rd.include(request, response);
		}*/
		
	}

}

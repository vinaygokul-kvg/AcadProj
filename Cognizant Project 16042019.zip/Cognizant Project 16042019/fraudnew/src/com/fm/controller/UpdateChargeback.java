package com.fm.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fm.model.inter.ChargeAppliedCustomersDAO;
import com.fm.model.inter.ChargeAppliedCustomersDAOimpl;
import com.fm.model.inter.FormDAO;
import com.fm.model.inter.FormDAOImpl;
import com.fm.model.pojo.ChargebackDetails;
import com.fm.model.pojo.Form;

/**
 * Servlet implementation class UpdateChargeback
 */
@WebServlet("/UpdateChargeback.do")
public class UpdateChargeback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateChargeback() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		int accountnumber=Integer.parseInt(request.getParameter("accountnumber"));
		Double newchargebackamount=Double.parseDouble(request.getParameter("newchargebackamount"));
		ChargebackDetails cd=new ChargebackDetails(accountnumber, newchargebackamount);
		ChargeAppliedCustomersDAO cddao=new ChargeAppliedCustomersDAOimpl();
		int status=cddao.updateChargeback(cd);
		RequestDispatcher rd=request.getRequestDispatcher("IndividualChargebackDetails.jsp");
		if(status==1)
		{
			pw.println("<span style=color:green;font-size:20px;>Chargeback Updated Successfully</span>");
			rd.include(request, response);
		}
		else
		{
			pw.println("<span style=color:red;size:20px>Failed Adding Customer</span>");
			rd.include(request, response);
		}
		
	
		
	}

}

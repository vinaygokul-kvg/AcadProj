package com.fm.model.pojo;

public class CustomerDetails {
	
	private int accountnumber;
	private String customername;
	private String contactnumber;
	private String email;
	private String acc_type;
	
	public CustomerDetails() {
		super();
	}

	public CustomerDetails(int accountnumber, String customername, String contactnumber) {
		super();
		this.accountnumber = accountnumber;
		this.customername = customername;
		this.contactnumber = contactnumber;
	}

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	
}

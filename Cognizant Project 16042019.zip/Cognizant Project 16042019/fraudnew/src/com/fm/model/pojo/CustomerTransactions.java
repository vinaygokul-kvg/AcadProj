package com.fm.model.pojo;

public class CustomerTransactions {

	private int accountnumber;
	private String slno;
	private String date;
	private String paymentdetails;
	private String debitcredit;
	private double amount;
	
	public int getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getSlno() {
		return slno;
	}
	public void setSlno(String slno) {
		this.slno = slno;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPaymentdetails() {
		return paymentdetails;
	}
	public void setPaymentdetails(String paymentdetails) {
		this.paymentdetails = paymentdetails;
	}
	public String getDebitcredit() {
		return debitcredit;
	}
	public void setDebitcredit(String debitcredit) {
		this.debitcredit = debitcredit;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public CustomerTransactions() {
		super();
	}
	public CustomerTransactions(int accountnumber, String slno, String date, String paymentdetails, String debitcredit,
			double amount) {
		super();
		this.accountnumber = accountnumber;
		this.slno = slno;
		this.date = date;
		this.paymentdetails = paymentdetails;
		this.debitcredit = debitcredit;
		this.amount = amount;
	}
}

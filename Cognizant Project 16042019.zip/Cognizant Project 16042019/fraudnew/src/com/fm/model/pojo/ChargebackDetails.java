package com.fm.model.pojo;

public class ChargebackDetails {

	private String customername;
	private int accountnumber;
	private double chargebackamount;
	private String date;
	private String reason;
	
	public ChargebackDetails(int accountnumber, double chargebackamount) {
		super();
		this.accountnumber = accountnumber;
		this.chargebackamount = chargebackamount;
	}

	public ChargebackDetails(String customername, int accountnumber, double chargebackamount) {
		super();
		this.customername = customername;
		this.accountnumber = accountnumber;
		this.chargebackamount = chargebackamount;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public double getChargebackamount() {
		return chargebackamount;
	}

	public void setChargebackamount(double chargebackamount) {
		this.chargebackamount = chargebackamount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public ChargebackDetails() {
		super();
	}

	public ChargebackDetails(String customername, int accountnumber, double chargebackamount, String date,
			String reason) {
		super();
		this.customername = customername;
		this.accountnumber = accountnumber;
		this.chargebackamount = chargebackamount;
		this.date = date;
		this.reason = reason;
	}
	
	
}

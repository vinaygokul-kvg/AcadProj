package com.fm.model.inter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fm.connection.ConnectionFactory;
import com.fm.model.pojo.CustomerDetails;
import com.fm.model.pojo.CustomerTransactions;

public class CustomerTransactionsDAOimpl implements CustomerTransactionsDAO{

	Connection con;	
	public CustomerTransactionsDAOimpl()
	{
		 con=ConnectionFactory.openConn();
	}
	public List<CustomerTransactions> getTransactionByAccNo(int accno) {
		
		List<CustomerTransactions> cuslist=new ArrayList<>();
		try {
			PreparedStatement psth= con.prepareStatement("select * from transactions where accountnumber=?");
			psth.setInt(1, accno);
			ResultSet rs=psth.executeQuery();
			while(rs.next())
			{
				CustomerTransactions ct=new CustomerTransactions();
				ct.setSlno(rs.getString(2));
				ct.setDate(rs.getString(3));
				ct.setPaymentdetails(rs.getString(4));
				ct.setDebitcredit(rs.getString(5));
				ct.setAmount(rs.getDouble(6));
				cuslist.add(ct);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return cuslist;
	}
	
	
	public List<CustomerTransactions> checkBillTransaction(int accno) {
		List<CustomerTransactions> datePaymentcheck=new ArrayList<CustomerTransactions>();
		try {			
			PreparedStatement psth= con.prepareStatement("select * from transactions where accountnumber=?");
			psth.setInt(1, accno);
			ResultSet rs=psth.executeQuery();
			while(rs.next())
			{
				CustomerTransactions cd=new CustomerTransactions();
				cd.setDate(rs.getString(3));
				cd.setPaymentdetails(rs.getString(4));
				datePaymentcheck.add(cd);
			}
		} catch (Exception e) {
			System.out.println("Error in checkBillTransaction "+e);
		}
		return datePaymentcheck;
	}
	

}

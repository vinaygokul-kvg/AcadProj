package com.fm.model.inter;

import java.util.List;

import com.fm.model.pojo.ChargebackDetails;
import com.fm.model.pojo.CustomerDetails;
import com.fm.model.pojo.CustomerTransactions;

public interface ChargeAppliedCustomersDAO {
	
	public List<ChargebackDetails> getAllChargeAppliedCustomers();
	public List<ChargebackDetails> getChargebackByAccNo(int accno);
	//public CustomerDetails getNameAccByuserId(int cus_id);
	public int updateChargeback(ChargebackDetails cbd);
}

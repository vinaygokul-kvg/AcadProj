package com.fm.model.inter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fm.connection.ConnectionFactory;
import com.fm.model.pojo.ChargebackDetails;
import com.fm.model.pojo.CustomerDetails;


public class ChargeAppliedCustomersDAOimpl implements ChargeAppliedCustomersDAO{

	Connection con;	
	public ChargeAppliedCustomersDAOimpl()
	{
		 con=ConnectionFactory.openConn();
	}
	public List<ChargebackDetails> getAllChargeAppliedCustomers() {
		List<ChargebackDetails> listEmp=new ArrayList<ChargebackDetails>();
		try {			
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from chargebackdetails");
			while(rs.next())
			{
				ChargebackDetails cbd=new ChargebackDetails();
				cbd.setAccountnumber(rs.getInt(2));
				cbd.setCustomername(rs.getString(1));
				cbd.setChargebackamount(rs.getDouble(3));
				
				listEmp.add(cbd);
			}
		} catch (Exception e) {
			System.out.println("Error in getAllChargeAppliedCustomers "+e);
		}
		return listEmp;
	}
	
	public List<ChargebackDetails> getChargebackByAccNo(int accno) {
			
			List<ChargebackDetails> cblist=new ArrayList<>();
			try {
				PreparedStatement psth= con.prepareStatement("select * from chargebackdetails where accountnumber=?");
				psth.setInt(1, accno);
				ResultSet rs=psth.executeQuery();
				while(rs.next())
				{
					ChargebackDetails cbd=new ChargebackDetails();
					
					cbd.setDate(rs.getString(4));
					cbd.setChargebackamount(rs.getDouble(3));
					cbd.setReason(rs.getString(5));
					
					cblist.add(cbd);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			return cblist;
		}
	
	
	public int updateChargeback(ChargebackDetails cbd) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("update chargebackdetails set chargebackamount=? where accountnumber=?");
			ps.setDouble(1, cbd.getChargebackamount());
			ps.setInt(2, cbd.getAccountnumber());
			
			status=ps.executeUpdate();
		}catch (Exception e) {
			System.out.println("Error in Update Chargeback "+e);
		}
		return status;
	}
	
	
	/*public ChargebackDetails getNameAccByuserId(int cus_id) {
		
		ChargebackDetails customer=null;
		try {			
		PreparedStatement ps= con.prepareStatement("select * from chargebackdetails where accountnumber=?");
		ps.setInt(1, cus_id);
		ResultSet rs= ps.executeQuery();
		if(rs.next())
		{
			customer=new ChargebackDetails();
			customer.setAccountnumber(rs.getInt(1));
			customer.setCustomername(rs.getString(2));
			
		}
		}catch (Exception e) {
			System.out.println();
		}
		
		return customer;
	}*/
}






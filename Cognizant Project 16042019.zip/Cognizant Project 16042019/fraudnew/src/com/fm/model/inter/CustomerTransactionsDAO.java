package com.fm.model.inter;

import java.util.List;

import com.fm.model.pojo.CustomerTransactions;

public interface CustomerTransactionsDAO {
	
	public List<CustomerTransactions> getTransactionByAccNo(int accno);
	public List<CustomerTransactions> checkBillTransaction(int accno);
}
